import java.util.Random;

public class QuickSort {

    public static void quickSort(int[] v, int low, int high){
        if (low < high){
            int r = randomPivotPartition(v, low, high);
            quickSort(v, low, r-1);
            quickSort(v, r+1, high);
        }
    }

    private static void swap(int[] v, int p, int q){
        int temp = v[p];
        v[p] = v[q];
        v[q] = temp;
    }

    private static int randomPivotPartition(int[] v, int low, int high){
        Random rand = new Random();

        int randomPivot = rand.nextInt((high-low) + 1) + low;

        swap(v, high, randomPivot);

        return partition(v, low, high);
    }

    private static int partition(int[] v, int low, int high){
        int i = low-1;
        int pivot = v[high];
        for(int j=low; j<=high; j++){
            if(v[j] <= pivot){
                i++;
                swap(v, i, j);
            }
        }
        return i;
    }

}
