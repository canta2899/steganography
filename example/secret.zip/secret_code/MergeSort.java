public class MergeSort {

    public static void mergeSort(int[] v, int low, int high){
        if(low < high){
            int mid = (low+high)/2;
            mergeSort(v, 0, mid); 
            mergeSort(v, mid+1, high);
            merge(v, low, mid, high);
        }
    }

    private static void merge(int[] v, int low, int mid, int high){
        int[] b = new int[high-low+1];
        int k = 0;
        int i = low;
        int j = mid+1;

        while(i <= mid && j <= high){
            if(v[i] < v[j]){
                b[k] = v[i];
                i++;
            }else{
                b[k] = v[j];
                j++;
            }
            k++;
        }

        while(i <= mid){
            b[k] = v[i];
            i++;
            k++;
        }

        while(j <= high){
            b[k] = v[j];
            j++;
            k++;
        }

        for(int x=low; x<=high; x++){
            v[x] = b[x-low];
        }
    }

}
